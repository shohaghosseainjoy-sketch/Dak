# 💬 NexChat — Real-Time Encrypted Messaging App

A complete, production-ready real-time messaging web app with Firebase backend, end-to-end encryption, push notifications, and a sleek black & white UI.

![NexChat](assets/favicon.svg)

---

## ✨ Features

| Feature | Status |
|---|---|
| 📱 Phone OTP Login | ✅ |
| ✉️ Email/Password Login | ✅ |
| ⚡ Real-time Messaging | ✅ |
| ✔✔ Message Status (Sent/Delivered/Seen) | ✅ |
| 🖼 Image / Video / Audio / File Sharing | ✅ |
| 🔔 Push Notifications (FCM) | ✅ |
| 👥 Contact System | ✅ |
| 🔒 End-to-End Encryption (AES-256-GCM) | ✅ |
| 🎤 Voice Messages | ✅ |
| ⌨️ Typing Indicator | ✅ |
| 🟢 Online / Offline Status | ✅ |
| 🕒 Last Seen | ✅ |
| 🔍 Chat Search | ✅ |
| 🚫 Block / Report Users | ✅ |
| ⚙️ Admin Panel | ✅ |
| 📲 PWA (Installable) | ✅ |
| 🌙 Dark Theme | ✅ |

---

## 📁 Project Structure

```
nexchat/
├── index.html              # Splash / landing page
├── login.html              # Login & registration
├── chat.html               # Main chat interface
├── profile.html            # Profile & settings
├── firebase-config.js      # Firebase configuration ⚠️ Edit this
├── firebase-messaging-sw.js # Service worker (FCM + PWA cache)
├── manifest.json           # PWA manifest
├── database.rules.json     # Firebase Realtime DB rules
├── storage.rules           # Firebase Storage rules
├── css/
│   ├── global.css          # Global styles & design tokens
│   ├── chat.css            # Chat layout styles
│   ├── login.css           # Login page styles
│   └── profile.css         # Profile page styles
├── js/
│   ├── encryption.js       # AES-256-GCM E2E encryption
│   ├── auth.js             # Authentication module
│   ├── messaging.js        # Real-time messaging module
│   ├── users.js            # User/contacts management
│   ├── notifications.js    # FCM push notifications
│   ├── utils.js            # Shared utilities
│   ├── login.js            # Login page controller
│   ├── chat.js             # Chat page controller
│   └── profile.js          # Profile page controller
└── assets/
    ├── favicon.svg
    ├── icon-72.png
    ├── icon-192.png
    └── icon-512.png
```

---

## 🚀 Setup Guide

### Step 1 — Create a Firebase Project

1. Go to [https://console.firebase.google.com](https://console.firebase.google.com)
2. Click **"Add project"**
3. Name it `nexchat` (or anything you like)
4. Enable Google Analytics (optional)
5. Click **Create project**

---

### Step 2 — Enable Firebase Services

Inside your Firebase project, enable these services:

#### 2a. Authentication
- Sidebar → **Authentication** → Get Started
- Enable **Phone** provider
- Enable **Email/Password** provider
- Add your domain to Authorized Domains (add `YOUR_USERNAME.github.io`)

#### 2b. Realtime Database
- Sidebar → **Realtime Database** → Create database
- Choose a region (e.g. `us-central1`)
- Start in **locked mode** (we'll set rules next)

#### 2c. Storage
- Sidebar → **Storage** → Get Started
- Accept defaults, start in production mode

#### 2d. Cloud Messaging (FCM)
- Sidebar → **Project Settings** → Cloud Messaging tab
- Copy your **Server Key** (for backend)
- Under "Web Push certificates" → Generate key pair
- Copy the **VAPID Key**

---

### Step 3 — Get Your Firebase Config

1. In Firebase Console → **Project Settings** (gear icon)
2. Under "Your apps" → click **</>** (Web)
3. Register app name: `NexChat`
4. Copy the `firebaseConfig` object

---

### Step 4 — Update `firebase-config.js`

Open `firebase-config.js` and replace the placeholder values:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",            // ← Your API key
  authDomain: "nexchat-xxx.firebaseapp.com",
  databaseURL: "https://nexchat-xxx-default-rtdb.firebaseio.com",
  projectId: "nexchat-xxx",
  storageBucket: "nexchat-xxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123",
  measurementId: "G-XXXXXXXX"
};

const FCM_VAPID_KEY = "YOUR_VAPID_KEY_HERE";
```

Also update the same values in **`firebase-messaging-sw.js`** (the service worker needs its own copy).

---

### Step 5 — Set Database Security Rules

1. Firebase Console → Realtime Database → **Rules** tab
2. Copy the contents of `database.rules.json` and paste them in
3. Click **Publish**

---

### Step 6 — Set Storage Rules

1. Firebase Console → Storage → **Rules** tab
2. Copy the contents of `storage.rules` and paste them in
3. Click **Publish**

---

### Step 7 — Upload to GitHub

#### Create a new repository:
```bash
git init
git add .
git commit -m "🚀 Initial commit - NexChat v1.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nexchat.git
git push -u origin main
```

#### Enable GitHub Pages:
1. Go to your repo on GitHub
2. **Settings** → **Pages**
3. Source: **Deploy from a branch**
4. Branch: `main` / `/ (root)`
5. Click **Save**
6. Your app will be live at: `https://YOUR_USERNAME.github.io/nexchat/`

---

### Step 8 — Add GitHub Pages Domain to Firebase

1. Firebase Console → Authentication → **Settings** → Authorized domains
2. Click **Add domain**
3. Enter: `YOUR_USERNAME.github.io`
4. Save

---

### Step 9 — Test Phone OTP

For phone authentication to work in production:
1. Firebase Console → Authentication → **Sign-in method** → Phone
2. Make sure Phone is **Enabled**
3. For testing, add test phone numbers under "Phone numbers for testing"

---

## 🔧 Local Development

No build step needed! Just open with a local server:

```bash
# Option 1: Python
python3 -m http.server 3000

# Option 2: Node.js (npx)
npx serve .

# Option 3: VS Code Live Server extension
# Right-click index.html → Open with Live Server
```

Then visit: `http://localhost:3000`

> ⚠️ **Important:** Firebase Phone Auth requires HTTPS or localhost. Use `localhost` for local dev, never `127.0.0.1`.

---

## 📲 Install as PWA

On mobile browsers:
1. Open the app URL in Chrome/Safari
2. Tap the browser menu
3. Select **"Add to Home Screen"**

The app will install like a native app with offline support.

---

## 🔒 Encryption Details

NexChat uses **AES-256-GCM** encryption via the Web Crypto API:

- A unique encryption key is derived per chat using **PBKDF2** with 100,000 iterations
- Keys are generated from both users' UIDs — never stored anywhere
- Each message uses a unique **random IV (nonce)**
- Only text messages are encrypted; media URLs are not (Firebase Storage handles access control)
- The encryption is **in-browser** — Firebase never sees plaintext messages

---

## 🛠 Customization

### Change App Name
Replace all instances of `NexChat` in HTML files with your app name.

### Change Colors
Edit CSS variables in `css/global.css`:
```css
:root {
  --bg-primary: #0a0a0a;    /* Main background */
  --accent: #ffffff;         /* Accent color */
  --bubble-out: #ffffff;     /* Your message bubble */
  --bubble-in: #1e1e1e;      /* Incoming bubble */
}
```

### Add More Languages / Countries
Edit the `COUNTRIES` array in `js/login.js`.

---

## 🐛 Common Issues

| Issue | Fix |
|---|---|
| OTP not received | Check Firebase Phone Auth is enabled; add test numbers for dev |
| reCAPTCHA error | Clear browser cache; ensure domain is in Firebase authorized list |
| Messages not loading | Check Realtime Database rules; ensure database URL is correct |
| File upload fails | Check Storage rules; ensure storageBucket is correct in config |
| Notifications not working | Ensure HTTPS; check VAPID key; grant notification permission |

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 🙏 Built With

- [Firebase](https://firebase.google.com) — Auth, Realtime Database, Storage, FCM
- [Web Crypto API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Crypto_API) — E2E Encryption
- [Google Fonts](https://fonts.google.com) — Syne + DM Sans
- Pure Vanilla JS — no frameworks needed

---

*Made with ❤️ — NexChat v1.0.0*
